EMBERWOOD VALE — DRAGON ISLAND

PLAY
Open Emberwood_Vale_Dragon_Island.html in a modern browser with WebGL enabled.
Choose your hero, then click Dragon Island at the lower left.
Travel to Dragonwatch for the safe sanctuary, or use Caldera overlook to see Vorthax.
All game scripts and model assets are embedded in the HTML.

UPGRADES
- 1,292 non-dragon creatures rebuilt with sculpted, articulated 3D silhouettes.
- Original Sky Lord dragon artwork retained.
- New 14,000 x 14,000 Dragon Island, matching the existing expanded world.
- Exactly 100 level-100 small dragons distributed across eight elemental provinces.
- Fire, Frost, Storm, Nature, Holy, Shadow, Water and Wind dragons.
- Vorthax at the map center: 20 times the original Sky Lord model scale.
- A 12,000,000-HP boss encounter with rotating elemental attacks and an enrage phase.
- Attack warnings, dodgeable ground strikes, jumpable shockwaves, enemy respawns.
- Hold right-click for repeated attacks, recovery sanctuary, island map and fast travel.
- Elemental groves, crystals, coastline, runic caldera and elevated viewpoint.

CONTROLS
WASD / arrows: move. Shift: run. Space: jump. G: dash.
Hold right-click: attack. 1–5: skills. Q: potion. E: interact / rest.
M: island map. Click the map to expand; click outside the central caldera to travel.
Mouse drag: rotate camera. Mouse wheel: zoom. Escape: close expansion panels.
Use Dragon Island > Return to Emberwood to leave.
Level 100+ and upgraded gear are recommended for island combat.

VALIDATION
Chromium checks passed for initialization, creature and dragon counts, all eight
elements, exact 20x scale, map dimensions, movement, sanctuary recovery, map
controls, damage warnings, successful dodges, death/rewards/respawn, boss melee
hit detection and return travel. Final bundle initialized with networking disabled.
No JavaScript runtime errors were observed in these checks.

This is a stylized 3D upgrade: non-dragon bodies are procedurally modeled;
the animated dragons reuse the detailed model embedded in the supplied game.
Performance depends on device graphics capability. Existing graphics settings
remain available through the gear button / backtick key.
